Please note, permission was granted for this project to be done in Hyperledger Fabric and Node.js over Solidity through Piazza.
The platform is permission based which ensures more safety in the healthcare setting. You notice this for when I code ACL. 
The powerpoint is a demonstration that summarizes my project and the importance of it. 
The code provides a catalog and permissions granted for access to records along with allowing new entries. 
Permissions have to be granted in order to view or modify patient records between chemists, the doctor, and pathology.
Different prescriptions are coded to be permitted if sent a request.
Insurance companies and hospitals were named after organizations in my home state. There was no collaboration and merely their names are used for proof of concept. 
For user logic, I entered a sample interaction for demonstration. 
I attached the powerpoint. Please let me know if you have difficulty opening it. Reminder that there is a time zone difference based on my location in Japan. 
Please let me know if you have any further questions and thank you for the class despite this difficult semester over COVID-19.